/*
    COMP9315 20T1 Assignment 2
    Group Name: Tonight Fight Tiger
    Students:
        Raymond Lu z5277884
        Haowei Huang z5247672
*/

#ifndef BSIG_H
#define BSIG_H 1

#include "defs.h"
#include "query.h"
#include "reln.h"
#include "bits.h"

void findPagesUsingBitSlices(Query);

#endif
